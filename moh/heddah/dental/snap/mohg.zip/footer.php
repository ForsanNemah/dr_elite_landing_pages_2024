
    <!-- Footer -->
    <footer class="page-footer font-small blue">
    
<!-- Copyright -->
 

<div class="footer-copyright text-center py-3">    

    
<br>
<br>
<br>
<br>
<br>
<br>
 <a style="color:blue;" href="privicy.php">سياسة الخصوصية  </a>

   
</div>
<!-- Copyright -->

</footer>