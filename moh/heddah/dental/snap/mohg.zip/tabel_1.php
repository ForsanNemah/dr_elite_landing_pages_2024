<div style="overflow-x:auto;">
  <table>
    <tr>
      <th>الاسم</th>
      <th>  رقم الجوال</th>
      <th>الوصف </th>
     
    </tr>
    <tr>
      <td>محسن</td>
      <td>0558777104</td>
      <td> </td>
     
      
    </tr>
    <tr>
      <td>ابو حيدر</td>
      <td>0505847810</td>
      <td></td>
     
    
    </tr>
    <tr>
      <td>ابو علي</td>
      <td>0544566074</td>
      <td></td>
    
   
    </tr>





    <tr>
      <td> اسلام</td>
      <td> 0565779915</td>
      <td></td>
    
   
    </tr>


    <tr>
      <td>ابو احمد</td>
      <td> 0561515250</td>
      <td></td>
    
   
    </tr>




    <tr>
      <td>   عمر</td>
      <td>0548212257 </td>
      <td>للتقسيط </td>
    
   
    </tr>







    <tr>
      <td>   ميثم</td>
      <td>0505892378 </td>
      <td>للتقسيط </td>
    
   
    </tr>


  </table>
</div>


<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>