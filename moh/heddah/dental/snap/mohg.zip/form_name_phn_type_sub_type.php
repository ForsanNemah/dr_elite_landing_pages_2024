 
 



							

<div class="form-group"  >
    <label class="sr-only" for="r-form-1-first-name"> Name</label>
    <input type="text" name="name"    placeholder="الأسم" class="r-form-1-first-name form-control" id="r-form-1-first-name" required  >
</div>
 
 


<div class="form-group"  >
    <label class="sr-only" for="r-form-1-email">Email</label>
    <input type="number"   name="phn" placeholder="رقم الهاتف " class="r-form-1-email form-control" id="r-form-1-email" required >
</div>


<div class="form-group"  hidden >
    <label class="sr-only" for="r-form-1-email">date</label>
    <input type="text" name="datetime" id="today" placeholder=" التاريخ  " class="r-form-1-email form-control" id="r-form-1-email"  >
</div>





<div class="form-group"  hidden >
    <label class="sr-only" for="r-form-1-email">source</label>
    <input type="text" name="source" id="source_id"  value="1" class="r-form-1-email form-control" id="r-form-1-email"  >
</div>




<div class="form-group"    >
<div  >
          <select name="cats1" id="cats1_id" class="custom-select" aria-label="عرض زراعة الأسنان" required="true" >

             



            <?php

include 'info.php';




foreach ($cats1 as $key => $value) {

echo "<option value='$value'>$value</option>";

}
?>
        </select>
    </div>
</div>





















 


<div class="form-group"    >
<div  >
          <select name="type" id="type_id" class="custom-select" aria-label="عرض زراعة الأسنان" required="true" >

             



    
        </select>
    </div>
</div>



 










 





    




<br>

 
 
<button type="submit"  class="btn submit-btn" style="background-color: #25D366"> <i >


<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16">
<path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
</svg>



</i> احجز   الآن </button>



<script>




    

    $(document).ready(function () {


        $('#type_id')
    .empty()
    .append('<option selected="selected" value="جلسة منطقه واحده">جلسة منطقه واحده</option>')

    .append('<option selected="selected" value="جلسة منطقتين ">جلسة منطقتين </option>')
    .append('<option selected="selected" value="جلسة فل بدي">جلسة فل بدي</option>')

    .append('<option selected="selected" value="اقة تحاليل تكيسات المبايض">اقة تحاليل تكيسات المبايض</option>')
    .append('<option selected="selected" value="باقة الحساسيه">باقة الحساسيه</option>')
    .append('<option selected="selected" value="باقة الامراض المتنقله جنسيا">باقة الامراض المتنقله جنسيا</option>')
    .append('<option selected="selected" value="باقة تحاليل تساقط الشعر">باقة تحاليل تساقط الشعر</option>')
    .append('<option selected="selected" value="باقة تحاليل الروكتان">باقة تحاليل الروكتان</option>')
    .append('<option selected="selected" value=" "> </option>');
     
      







        $('#cats1_id').on('change', function()
{
     

    cat1=this.value;
    //alert(cat1);


    if(cat1.trim() ==="رجال".trim()  ){
       // alert("ayb");
        
        

        $('#type_id')
    .empty()
    .append('<option selected="selected" value="جلسة منطقه واحده">جلسة منطقه واحده</option>')
    .append('<option selected="selected" value="جلسة منطقتين">جلسة منطقتين</option>')
    .append('<option selected="selected" value="جلسة 3 مناطق">جلسة 3 مناطق</option>')
    .append('<option selected="selected" value="جلسة فل بدي">جلسة فل بدي</option>')
  

    ;
       
      
         
 


    }
    



});


    
    });
</script>











