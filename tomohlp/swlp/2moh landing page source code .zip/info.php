<?php


$website_name="

طموح    لتقنية المعلومات  



 
";

$dr_name="

 بدون نظام الكتروني مشروعك مهدد بالفشل

 💔
";

$phone_main="966569070115";
$group_id="120363345095090780";
$logo="footer_logo/2moh.png";

$dental_services_select=0;
$derma_services_select=1;


$action_url="https://script.google.com/macros/s/AKfycbwjQoZ0Ej3OvW_dctNajx7YeXDjNa8eAmZS-8L6fViXRX37uhfteyVX5c2tDoa-JcWFZw/exec";

$sheet_url="https://docs.google.com/spreadsheets/d/1Cw50UoyyK4IobN-9q5YLT7LorvrF1xpPkV0_PTJK-MI/edit?usp=sharing";

$form1_des="

عرض شهر نوفمبر
"; 
$cta=0;
$cta_text="احجز الان";
$form1_des2="

سجل بيانتك لتحصل على استشارة مجانية  
";

$form1_des3="


 

";





$form2_des="

قم بتعبئة البيانات

";


$form2_des2="

وسيتم تحويلك الى واتساب مباشرة

";




$footer_des1="

قمة الإنتشار للتسويق الإلكتروني  

";



$footer_des2="

 

";



$footer_des3="

سجل تجاري رقم 

 <br>
2051251848
<br>
<a href= 'mailto:info@intshar.net' style='color: white;'>info@intshar.net</a>

<br>

<a href='tel:'.$phone_main.' style='color: white;'>$phone_main</a>

<br>
المملكة العربية السعودية-الخبر
";



$footer_des4="

المملكة العربية السعودية-الخبر

";








$before_after=0;
$map=0;
$services=0;
$derma_services=0;
$services2=0;
$faq=0;
$process=0;
$services_images=0;
$footer=1;
$footer2=0;
$w_app_button=0;
$api_notification=1;
$group_notification=1;
$ad_source="snap ";
$header=0;
$parteners=0;
$about_image=0;

$services_list=1;
$taby_and_tamara=0;
$footer_cr=1;
$videos=0;
$snap_capi=0;
$w_btn_only=1;
$pm_register=0;





$pixel_id = "77ec2e1e-c2bb-468f-8d2e-f99b7ec9983c";
$authorization_token = "eyJhbGciOiJIUzI1NiIsImtpZCI6IkNhbnZhc1MyU0hNQUNQcm9kIiwidHlwIjoiSldUIn0.eyJhdWQiOiJjYW52YXMtY2FudmFzYXBpIiwiaXNzIjoiY2FudmFzLXMyc3Rva2VuIiwibmJmIjoxNzI0NjIwODIzLCJzdWIiOiJhMTAzMjVhMi0zMzU1LTRkMjMtODhmOC04MmFmZTc3NzYzOTR-UFJPRFVDVElPTn4yNTZmYTNlNi1iZDhmLTQwMTctYTQ2MC0yYjU2OGI4MDJiMWQifQ.7-CnLhZlNw3mr9vkdWMMtVoUz0CONBGZibDPEOEo8Es";



$wapi_profile_id="a0aca078-18a5";
$wapi_token="9f9151b56d756354026b368ecc644edec19343b4";










/*



*/

?>