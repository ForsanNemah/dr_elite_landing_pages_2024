<header class="py-5 mt-5 text-center mainbg" >
  <div class="container">
    <h1 class="display-4 fw-bold" style="font-size: 3rem; letter-spacing: 1px;">
      مستقبل الصحة النفسية
    </h1>
    <p class="lead mt-3 mb-4" style="font-size: 1.2rem; max-width: 600px; margin: 0 auto;">
      أول منصة لقياس تقدم صحتك النفسية بدقة باستخدام الذكاء الاصطناعي
    </p>
    
    <!-- Booking Button -->
    <a data-aos="zoom-in-up" href="#service1_id" class="btn btn-primary btn-lg" style="border-radius: 50px; padding: 15px 40px; transition: all 0.3s ease-in-out;">
      احجز الآن
    </a>
  </div>
</header>
