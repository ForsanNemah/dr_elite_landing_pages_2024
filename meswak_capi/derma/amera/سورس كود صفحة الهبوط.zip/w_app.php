<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">




<a href="#w_app_form" class="float"  onclick="show_w_app_form()" >
<i class="fa fa-whatsapp my-float"></i>
</a>


<?php 


/*
$w_message="   الاطلاع على العروض ";
echo '


<a href="https://api.whatsapp.com/send?phone='.$phone_main.'&text='.urlencode($w_message).'" class="float" >
<i class="fa fa-whatsapp my-float"></i>
</a>

';

*/

?>

















<style>




.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:100px;
	left:10px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
}
</style>




<script>
  function show_w_app_form() {
    // Your custom JavaScript code here
    // For example, you can display an alert
    //alert('Link clicked!');



	var w_app_form_div = document.getElementById("w_app_form");
     w_app_form_div.style.display = "block";





  }
</script>
