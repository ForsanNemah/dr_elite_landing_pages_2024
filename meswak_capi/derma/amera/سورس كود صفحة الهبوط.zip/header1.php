echo '



  <div >
    <div class="text-center image-container">
      <img src="images/v.jpg" alt="Book Image Mobile" class="img-fluid mobile-image">
      <img src="images/h.jpg" alt="Book Image Desktop" class="img-fluid desktop-image">
      <a href="#packages">


      <button   class="btn btn-primary centered-button btn-booking rounded-pill pulsate"> 
      
      
      
      
      احجز الحين
      
      
      
      </button>

      </a>
     
    </div>
  </div>








';