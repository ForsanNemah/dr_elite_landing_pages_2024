<!DOCTYPE html>
<html dir="rtl" lang="ar"">

<?php
include "head.php";
include "info.php";
include "nav_offers.php";

 

?>

<body>











<?php


include "offers_section.php";


?>






















<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>



<script src="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/js/all.min.js"
  integrity="sha384-PASTE-INTEGRITY-HERE"
  crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-PASTE-INTEGRITY-HERE"
  crossorigin="anonymous"></script>



  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script>
AOS.init();
</script>

</body>

</html>