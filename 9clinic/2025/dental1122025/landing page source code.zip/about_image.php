


<div id="about_id" class="mb-4"  >

 <br>
</div>

 

<div  >
    
    <div class="text-center image-container mt-4" data-aos-duration="1500" data-aos="zoom-in-up">
      <img src="images/about_v.jpg" alt="Book Image Mobile" class="img-fluid mobile-image">
      <img src="images/about_h.jpg" alt="Book Image Desktop" class="img-fluid desktop-image">
      <a href="#myform">

     

      </a>
     
    </div>
  </div>