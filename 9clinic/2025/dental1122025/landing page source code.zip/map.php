 
  <div class="container my-5" data-aos-duration="1500" data-aos="zoom-in-up">
    <div class="row">
      <div class="col-12">
        <div class="ratio ratio-16x9">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3576.5835745816726!2d50.21378028496778!3d26.30759648339193!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49e9b4961f5131%3A0x63c5ef587d959ad3!2z2YLZhdipINin2YTYpdmG2KrYtNin2LEg2YTZhNiq2LPZiNmK2YIg2KfZhNil2YTZg9iq2LHZiNmG2Yo!5e0!3m2!1sar!2ssa!4v1716715154640!5m2!1sar!2ssa" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>
  </div>
  