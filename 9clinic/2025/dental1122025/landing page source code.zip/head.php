<head>



<?php
error_reporting(E_ERROR | E_PARSE);



session_start();


function hash_to_256($input_string) {
    return hash('sha256', $input_string);
}











$ScCid = $_GET['scCid'];



//echo $ScCid;
$_SESSION['ScCid']=$ScCid;
//session_start();
//echo $_SESSION['ScCid']." from session";
//echo  $_SESSION['ScCid'];
 

















 
include "info.php";

if($snap_capi==1){	

	include "capi_page_view.php";
	//include "capi_signup.php";


	}





?>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css">
  <title>
    
  
  
  
<?php

echo $website_name;

?>





  </title>
  


<link href="https://fonts.cdnfonts.com/css/tajawal" rel="stylesheet">

<link rel="stylesheet" href="style.css">



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>














 
<script>

	var snap_pixel_on=1;
	var tiktok_pixel_on=1;








	

	if( tiktok_pixel_on==1){


		!function (w, d, t) {
		  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++
)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};n=document.createElement("script");n.type="text/javascript",n.async=!0,n.src=i+"?sdkid="+e+"&lib="+t;e=document.getElementsByTagName("script")[0];e.parentNode.insertBefore(n,e)};
		
		  ttq.load('CN6FRCRC77UC2DCHBISG');
		  ttq.load('CTJV35BC77UDUQAQIJVG');
		  ttq.load('CRF3C93C77UD2MA149N0');
		  ttq.load('CPF2OSJC77UBKGA91FLG');
		  ttq.load('CV2D80JC77U108FEF97G');
		  ttq.load('CUUBDIJC77U38KO2H2MG');
		  ttq.page();



		  ttq.track('Purchase', {
    value: 100.00,  // Replace with the actual purchase amount
    currency: 'USD', // Replace with the correct currency
    content_id: '12345', // Replace with the actual content/product ID
    content_type: 'product', // Can be 'product' or 'service' based on what you're selling
});






		  ttq.track('CompleteRegistration', {});

		}(window, document, 'ttq');


	}
		



	</script>



 


<script>



if(snap_pixel_on==1)
{
var event_phn="966568430828";
var event_email="info@wmc-ksa.com";

(function(e,t,n){if(e.snaptr)return;var a=e.snaptr=function()
{a.handleRequest?a.handleRequest.apply(a,arguments):a.queue.push(arguments)};
a.queue=[];var s='script';r=t.createElement(s);r.async=!0;
r.src=n;var u=t.getElementsByTagName(s)[0];
u.parentNode.insertBefore(r,u);})(window,document,
'https://sc-static.net/scevent.min.js');

snaptr('init', 'b2436d09-c13e-4280-9181-caa1960c5448');

//snaptr('track', 'PAGE_VIEW');
 
 

snaptr('init', 'b67a49ad-d1f1-445f-941f-31aea29bc8e4');



 




snaptr('init', '44ba299e-fb73-42fb-9f3f-bc272806a7ba');
snaptr('init', '91430838-f2f4-42e4-8d7f-d957d09436d6');
snaptr('init', '6dd030e2-9f73-4c57-a963-76eb6785f85f');
snaptr('init', '6fc02db2-6e68-40ab-8290-979b40236fe2');
snaptr('init', 'cbb29236-8b8c-44f0-9178-303d7d9d2834');




snaptr('init', '44ba299e-fb73-42fb-9f3f-bc272806a7ba');
snaptr('init', '3ea6c409-e709-48b5-919d-cddc20dc04f9');
snaptr('init', '8b8f6ecc-c384-47e4-b630-ce8ae2e01762');



snaptr('init', 'cfe244a1-451c-4564-a284-5283bf57a6c1');
snaptr('init', '9d462518-e893-4292-aef7-c54b0e57f28f');
snaptr('init', 'b2436d09-c13e-4280-9181-caa1960c5448');
snaptr('init', 'fc185b6c-2c56-4aa5-8bb6-ed5f470969fc');
snaptr('init', 'b03a5fe0-a066-4e30-a1e9-28ab9616adf9');
snaptr('track', 'PAGE_VIEW');
snaptr('track', 'ADD_CART');
snaptr('track', 'PURCHASE');



}

    </script>












<script>




var sha256 = function sha256(ascii) {
	function rightRotate(value, amount) {
		return (value>>>amount) | (value<<(32 - amount));
	};
	
	var mathPow = Math.pow;
	var maxWord = mathPow(2, 32);
	var lengthProperty = 'length'
	var i, j; // Used as a counter across the whole file
	var result = ''

	var words = [];
	var asciiBitLength = ascii[lengthProperty]*8;
	
	//* caching results is optional - remove/add slash from front of this line to toggle
	// Initial hash value: first 32 bits of the fractional parts of the square roots of the first 8 primes
	// (we actually calculate the first 64, but extra values are just ignored)
	var hash = sha256.h = sha256.h || [];
	// Round constants: first 32 bits of the fractional parts of the cube roots of the first 64 primes
	var k = sha256.k = sha256.k || [];
	var primeCounter = k[lengthProperty];
	/*/
	var hash = [], k = [];
	var primeCounter = 0;
	//*/

	var isComposite = {};
	for (var candidate = 2; primeCounter < 64; candidate++) {
		if (!isComposite[candidate]) {
			for (i = 0; i < 313; i += candidate) {
				isComposite[i] = candidate;
			}
			hash[primeCounter] = (mathPow(candidate, .5)*maxWord)|0;
			k[primeCounter++] = (mathPow(candidate, 1/3)*maxWord)|0;
		}
	}
	
	ascii += '\x80' // Append Ƈ' bit (plus zero padding)
	while (ascii[lengthProperty]%64 - 56) ascii += '\x00' // More zero padding
	for (i = 0; i < ascii[lengthProperty]; i++) {
		j = ascii.charCodeAt(i);
		if (j>>8) return; // ASCII check: only accept characters in range 0-255
		words[i>>2] |= j << ((3 - i)%4)*8;
	}
	words[words[lengthProperty]] = ((asciiBitLength/maxWord)|0);
	words[words[lengthProperty]] = (asciiBitLength)
	
	// process each chunk
	for (j = 0; j < words[lengthProperty];) {
		var w = words.slice(j, j += 16); // The message is expanded into 64 words as part of the iteration
		var oldHash = hash;
		// This is now the undefinedworking hash", often labelled as variables a...g
		// (we have to truncate as well, otherwise extra entries at the end accumulate
		hash = hash.slice(0, 8);
		
		for (i = 0; i < 64; i++) {
			var i2 = i + j;
			// Expand the message into 64 words
			// Used below if 
			var w15 = w[i - 15], w2 = w[i - 2];

			// Iterate
			var a = hash[0], e = hash[4];
			var temp1 = hash[7]
				+ (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) // S1
				+ ((e&hash[5])^((~e)&hash[6])) // ch
				+ k[i]
				// Expand the message schedule if needed
				+ (w[i] = (i < 16) ? w[i] : (
						w[i - 16]
						+ (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15>>>3)) // s0
						+ w[i - 7]
						+ (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2>>>10)) // s1
					)|0
				);
			// This is only used once, so *could* be moved below, but it only saves 4 bytes and makes things unreadble
			var temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) // S0
				+ ((a&hash[1])^(a&hash[2])^(hash[1]&hash[2])); // maj
			
			hash = [(temp1 + temp2)|0].concat(hash); // We don't bother trimming off the extra ones, they're harmless as long as we're truncating when we do the slice()
			hash[4] = (hash[4] + temp1)|0;
		}
		
		for (i = 0; i < 8; i++) {
			hash[i] = (hash[i] + oldHash[i])|0;
		}
	}
	
	for (i = 0; i < 8; i++) {
		for (j = 3; j + 1; j--) {
			var b = (hash[i]>>(j*8))&255;
			result += ((b < 16) ? 0 : '') + b.toString(16);
		}
	}
	return result;
};

//alert(sha256("7777"));

</script>


<?php

//include "seo_keywords.php";

?>


<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/css/select2.min.css" rel="stylesheet" />



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<link rel="apple-touch-icon" sizes="57x57" href="fav/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="fav/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="fav/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="fav/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="fav/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="fav/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="fav/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="fav/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="fav/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="fav/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="fav/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="fav/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="fav/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="fav/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">




<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<script>
  function checkLength(input) {
    if (input.value.length < 9) {
      input.setCustomValidity(" الرجاء ادخال رقم هاتف صحيح  ");
    } else {
      input.setCustomValidity(""); // Valid input
    }
  }
</script>



















<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "p2q78o1f7y");








	//alert("end head");
</script>










<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "p9645ci8me");
</script>




























<!-- Meta Pixel Base Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;
  n.push=n;
  n.loaded=!0;
  n.version='2.0';
  n.queue=[];
  t=b.createElement(e);
  t.async=!0;
  t.src=v;
  s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}
  (window, document,'script','https://connect.facebook.net/en_US/fbevents.js');

  fbq('init', '5962331043832490'); 
  fbq('track', 'PageView');
</script>
<noscript>
  <img height="1" width="1" 
  src="https://www.facebook.com/tr?id=5962331043832490&ev=PageView&noscript=1"/>
</noscript>

<!-- Purchase Event -->
<script>
  fbq('track', 'Purchase', {
    value: 99.99, // Update with actual purchase value
    currency: 'USD' // Change to the appropriate currency (e.g., SAR, EUR)
  });
</script>











</head>