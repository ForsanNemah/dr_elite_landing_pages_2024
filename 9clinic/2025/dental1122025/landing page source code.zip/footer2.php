<footer class="bg-dark text-light py-3">
  <div class="container text-center">
     
   
    <a  style="  color: white;" href="https://2moh.net/">

    بواسطة طموح  للتسويق الالكتروني 
    

    </a>
  </div>
</footer>